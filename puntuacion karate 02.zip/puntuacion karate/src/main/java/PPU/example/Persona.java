package PPU.example;

public class Persona {
}
