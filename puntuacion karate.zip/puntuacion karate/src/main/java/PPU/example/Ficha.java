package PPU.example;

public abstract class Ficha {
    String nombre;
    String rut;
    int edad;
    String rango;
    String origen;

}
