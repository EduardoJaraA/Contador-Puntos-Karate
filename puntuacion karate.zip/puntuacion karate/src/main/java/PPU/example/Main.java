package PPU.example;

public class Main {
    public static void main(String[] args) {

        Ventana principal= new Ventana();
        principal.setVisible(true);

    }
}