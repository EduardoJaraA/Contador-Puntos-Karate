package PPU.example;
import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Ventana principal= new Ventana();
        principal.setVisible(true);
        Scanner teclado =new Scanner(System.in);
        int res =teclado.nextInt();
        while (res == 0){
            String url ="jdbc://localhost:3306/testeo";
            String user="root";
            String password="root@123";

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection connection= DriverManager.getConnection(url,user,password);
                System.out.println("conecion exitosa con la base de datos"+url);
                String query = "Ingrese el concursante(id, nombre) values(101,'ram')";
                Statement statement = connection.createStatement();
                statement.executeQuery(query);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}