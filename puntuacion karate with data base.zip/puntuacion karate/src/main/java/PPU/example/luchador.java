package PPU.example;

public class luchador extends Ficha{
    String nombre;
    String rut;
    int edad;
    String rango;
    String origen;
}
